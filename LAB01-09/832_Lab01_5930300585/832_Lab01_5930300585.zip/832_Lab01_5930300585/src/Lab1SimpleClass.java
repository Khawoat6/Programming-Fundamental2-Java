
public class Lab1SimpleClass 
{

	public static void main(String[] args) 
	{
		
		System.out.println( "18 and 81 :" + 24 + 45 );     // 18 and 81 :2445
		
		System.out.println( "18 and 81 : " + (24 + 45) );	// 18 and 81 : 69
		
	}

}
