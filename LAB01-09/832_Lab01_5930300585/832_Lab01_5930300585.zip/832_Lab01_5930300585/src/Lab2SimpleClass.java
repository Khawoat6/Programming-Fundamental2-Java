
public class Lab2SimpleClass 
{

	public static void main(String[] args) 
	{
		
		System.out.println("I Love JAVA");		// I Love JAVA
		System.out.println("I Love 'JAVA'");  	// I Love 'JAVA'
		//System.out.println("I Love "JAVA"");  // Error
		//System.out.println("I Love \JAVA\");  // Error
		System.out.println("I Love \\JAVA\\");	// I Love \JAVA\
		System.out.println("I Love \"JAVA\"");	// I Love "JAVA"
		System.out.println("\tI Love JAVA");	// 		I Love JAVA
		System.out.println("I Love JAVA,OOP");	// I Love JAVA,OOP

	}

}
