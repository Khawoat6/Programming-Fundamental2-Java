
public class Lab5SimpleClass 
{

	public static void main(String[] args) 
	{
		
		int a , b , c ;
		a = 4 ;
		b = 8 ;
		c = a * b - ( b + a ) ;
		System.out.println( a + " x " + b + " - " + "(" + b + " + " + a + ")" + " = " + c );
		
		// 4 x 8 - (8 + 4) = 20
	}

}
