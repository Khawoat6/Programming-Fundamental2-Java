
public class Lab6CelTofar 
{

	public static void main(String[] args) 
	{
		// Fahrenheit = 9/5 Celsius + 32 
		
		final int Celsius = 24 ;
		double F = ( 9.0/5.0 ) * Celsius + 32 ;
		System.out.println("Celsius Temperature : " + Celsius) ;	// Celsius Temperature : 24
		System.out.println("Fahrenheit Equivalent : " + F );		// Fahrenheit Equivalent : 75.2
		
	}

}
