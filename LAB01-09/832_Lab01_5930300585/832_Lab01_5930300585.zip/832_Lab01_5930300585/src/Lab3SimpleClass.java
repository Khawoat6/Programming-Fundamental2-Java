
public class Lab3SimpleClass 
{

	public static void main(String[] args) 
	{
		
		int keys = 88;
		System.out.println( "A piano has " + keys + keys );		// A piano has 8888
		
		//int keys = 88;
		//System.out.println( "A piano has " + keys + " keys" );		// A piano has 88 keys
		
		
	}

}
