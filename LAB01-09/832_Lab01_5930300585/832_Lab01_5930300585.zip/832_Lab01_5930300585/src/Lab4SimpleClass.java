
public class Lab4SimpleClass 
{

	public static void main(String[] args) 
	{
		
		int  a, b, c ;
		a = 4;
		b = 7;
		c = a * b;
		System.out.println( a + " x " + b + " = " + c );	// 4 x 7 = 28
		
	}

}
